void increment() {
  count++;
}
