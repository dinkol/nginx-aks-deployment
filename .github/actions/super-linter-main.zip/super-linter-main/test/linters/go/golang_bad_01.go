if len(in) == 0 {
  return "", fmt.Errorf("Input is empty")
}
