/** Represents a good Java file. */
public static class JavaGood {
  // Prints "Hello, World" to the terminal window.
  private void helloWorld() {
    System.out.println("Hello, World");
  }
}
