# Good Markdown

This is just standard good markdown.

## Second level header

This header follows the step down from `level 1`.

- Here it *is*
  - Some more **indention**
    - why so much?

```bash
ls -la
```

### Walk away

We're all done **here**.
- [Link Action](https://github.com)
