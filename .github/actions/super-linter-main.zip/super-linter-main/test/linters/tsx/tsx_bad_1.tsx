var foo = bar as
