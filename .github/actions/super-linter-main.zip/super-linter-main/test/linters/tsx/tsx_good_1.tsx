var foo = bar as foo;
